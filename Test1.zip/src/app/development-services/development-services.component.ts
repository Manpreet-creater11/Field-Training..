import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-development-services',
  imports: [RouterLink,RouterOutlet],
  templateUrl: './development-services.component.html',
  styleUrl: './development-services.component.css'
})
export class DevelopmentServicesComponent {

}
