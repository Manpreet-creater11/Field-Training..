import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-sub-catagory',
  imports: [RouterLink ,RouterOutlet],
  templateUrl: './sub-catagory.component.html',
  styleUrl: './sub-catagory.component.css'
})
export class SubCatagoryComponent {

}
