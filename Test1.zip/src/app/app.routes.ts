import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ProductsComponent } from './products/products.component';
import { ServicesComponent } from './services/services.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CatagoryComponent } from './catagory/catagory.component';
import { SubCatagoryComponent } from './sub-catagory/sub-catagory.component';
import { DevelopmentServicesComponent } from './development-services/development-services.component';
import { TrainingServicesComponent } from './training-services/training-services.component';

export const routes: Routes = [
    { path:'' , redirectTo:'/Home' , pathMatch:'full'},
    
    {path:'Home', component:HomeComponent},
    {path:'About', component:AboutComponent , children:[{
        path:'ContactUs', component:ContactUsComponent  
    },
]},

    {path:'Products', component:ProductsComponent , children:[
        {path:'Catagory', component:CatagoryComponent},
    {path:'SubCatagory', component:SubCatagoryComponent},
    ]},

    {path:'Services', component:ServicesComponent, children:[
        {path:'DevelopmentServices', component:DevelopmentServicesComponent},
        {path:'TrainingServices', component:TrainingServicesComponent},
    ]},
    
    {path:'ContactUs', component:ContactUsComponent},
    {path:'Catagory', component:CatagoryComponent},
    {path:'SubCatagory', component:SubCatagoryComponent},
    {path:'DevelopmentServices', component:DevelopmentServicesComponent},
    {path:'TrainingServices', component:TrainingServicesComponent},
    
];
