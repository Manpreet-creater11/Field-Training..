import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-training-services',
  imports: [RouterLink,RouterOutlet],
  templateUrl: './training-services.component.html',
  styleUrl: './training-services.component.css'
})
export class TrainingServicesComponent {

}
